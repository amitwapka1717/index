# Cars Top Trumps

A simple top trumps game made with vanilla JS. Each player has 15 cards. The first player to have 30 cards within their deck, wins the game.

# Technicalities
Cards are sorted entirely at random using an adaptation of the fisher yates shuffle method. 

### By George Field
